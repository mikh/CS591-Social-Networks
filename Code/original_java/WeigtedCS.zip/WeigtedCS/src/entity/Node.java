package entity;

public class Node {

	public Integer id;
	public double initP;
	
	public Node(Integer id){
		this.id = id;
		this.initP = 0;
	}
}
